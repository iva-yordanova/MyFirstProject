package com.company;

public class Name {

    public static void main(String[] args) {

        String firstName="Iva";
        String middleName="Luybomirova";
        String lastName="Yordanova";
        String fullName= firstName + " "+ middleName + " "+ lastName;

        System.out.println("My name is:" + " " + fullName);
    }
}
